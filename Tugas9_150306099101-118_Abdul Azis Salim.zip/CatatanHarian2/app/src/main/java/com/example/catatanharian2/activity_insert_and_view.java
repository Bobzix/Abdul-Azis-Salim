package com.example.catatanharian2;

public class activity_insert_and_view {
}
